Feeding In Your Data
====================
...


The plaintext protocol
----------------------
...


The pickle protocol
-------------------
...


Using AMQP
----------
...
