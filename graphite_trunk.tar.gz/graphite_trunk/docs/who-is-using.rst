Who is using Graphite?
======================

Here are some organizations that use Graphite:

* `Orbitz <http://www.orbitz.com/>`_
* `Sears Holdings <http://www.sears.com/>`_
* `Etsy <http://www.etsy.com/>`_ (see http://codeascraft.etsy.com/2010/12/08/track-every-release/)
* `Google <http://google-opensource.blogspot.com/2010/09/get-ready-to-rocksteady.html>`_ (opensource Rocksteady project)
* `Media Temple <http://mediatemple.net/>`_

And many more, I still need to collect some links...
